CREATE OR REPLACE VIEW vista_estadisticas_ventas_anuales AS
WITH ventas_por_anio AS (
  SELECT 
    YEAR(fecha_venta) AS anio,
    estado_venta,
    COUNT(*) AS cantidad
  FROM tienda_guitarras.ventas
  GROUP BY anio, estado_venta
),
total_anual AS (
  SELECT 
    anio,
    SUM(cantidad) AS total_anio
  FROM ventas_por_anio
  GROUP BY anio
),
monto_por_estado AS (
  SELECT
    YEAR(fecha_venta) AS anio,
    estado_venta,
    SUM(total) AS total_dinero
  FROM tienda_guitarras.ventas
  GROUP BY anio, estado_venta
),
monto_total_anual AS (
  SELECT
    YEAR(fecha_venta) AS anio,
    SUM(total) AS total_dinero_anual
  FROM tienda_guitarras.ventas
  GROUP BY anio
)
SELECT 
  v.anio,
  v.estado_venta,
  v.cantidad,
  t.total_anio,
  ROUND((v.cantidad * 100.0 / t.total_anio), 2) AS porcentaje_ventas,
  m.total_dinero,
  ROUND((m.total_dinero * 100.0 / mt.total_dinero_anual), 2) AS porcentaje_dinero
FROM ventas_por_anio v
JOIN total_anual t ON v.anio = t.anio
LEFT JOIN monto_por_estado m ON v.anio = m.anio AND v.estado_venta = m.estado_venta
LEFT JOIN monto_total_anual mt ON v.anio = mt.anio;
