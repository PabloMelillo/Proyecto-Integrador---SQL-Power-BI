-- evolucion de ventas año a año

use tienda_guitarras;

SELECT 
  YEAR(v.fecha_venta) AS anio,
  MONTH(v.fecha_venta) AS mes,
  COUNT(*) AS cantidad_ventas,
  SUM(v.total) AS total_facturado
FROM tienda_guitarras.ventas v
WHERE v.estado_venta = 'Pagada'
GROUP BY anio, mes
ORDER BY mes, anio;