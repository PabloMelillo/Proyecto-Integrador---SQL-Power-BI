/*
	Rangos de edad que más compran guitarras y tipo de guitarra
	Primero, definimos rangos de edad teniendo en cuenta que la tabla clientes tiene
    fecha_nacimiento, calculamos la edad y la agrupamos.
*/

use tienda_guitarras;

SELECT 
  CASE
    -- usamos "TIMESTAMPDIF" que calcula la diferencia entre dos fechas
    -- y lo comparamos con "curdate()" que es la fecha actual.
    -- asi obtenemos la edad de los clientes.
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) < 20 THEN '-20' 
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 20 AND 29 THEN '20-29'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 30 AND 39 THEN '30-39'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 40 AND 49 THEN '40-49'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) >= 50 THEN '50+'
    ELSE 'Desconocido'
  END AS rango_edad,
  pr.tipo,
  COUNT(dv.id_detalle) AS cantidad_comprada,
  SUM(dv.subtotal) AS total_gastado
FROM tienda_guitarras.detalle_venta dv
JOIN tienda_guitarras.ventas v ON dv.id_venta = v.id_venta
JOIN tienda_guitarras.clientes c ON v.id_cliente = c.id_cliente
JOIN tienda_guitarras.productos pr ON dv.id_producto = pr.id_producto
WHERE v.estado_venta = 'Pagada'
GROUP BY rango_edad, pr.tipo
ORDER BY rango_edad, cantidad_comprada DESC;

/* si queremos saber cual de los rangos compro mas o gasto mas, hacemos una modificacion, agrupando por rango edad*/

SELECT 
  CASE
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) < 20 THEN '-20' 
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 20 AND 29 THEN '20-29'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 30 AND 39 THEN '30-39'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 40 AND 49 THEN '40-49'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) >= 50 THEN '50+'
    ELSE 'Desconocido'
  END AS rango_edad,
  COUNT(dv.id_detalle) AS cantidad_comprada,
  SUM(dv.subtotal) AS total_gastado
FROM tienda_guitarras.detalle_venta dv
JOIN tienda_guitarras.ventas v ON dv.id_venta = v.id_venta
JOIN tienda_guitarras.clientes c ON v.id_cliente = c.id_cliente
WHERE v.estado_venta = 'Pagada'
GROUP BY rango_edad
ORDER BY total_gastado DESC;
-- esto se puede aprovechar para hacer con power bi 

/* haremos vistas de lo consultado para que puedan verse desde power bi*/

CREATE OR REPLACE VIEW vista_ventas_por_rango_edad AS
SELECT 
  CASE
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) < 20 THEN '-20' 
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 20 AND 29 THEN '20-29'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 30 AND 39 THEN '30-39'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 40 AND 49 THEN '40-49'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) >= 50 THEN '50+'
    ELSE 'Desconocido'
  END AS rango_edad,
  COUNT(dv.id_detalle) AS cantidad_comprada,
  SUM(dv.subtotal) AS total_gastado
FROM tienda_guitarras.detalle_venta dv
JOIN tienda_guitarras.ventas v ON dv.id_venta = v.id_venta
JOIN tienda_guitarras.clientes c ON v.id_cliente = c.id_cliente
WHERE v.estado_venta = 'Pagada'
GROUP BY rango_edad;

/* ahora vistas por rango de edad y tipo de guitarra comprada*/

CREATE OR REPLACE VIEW vista_guitarras_por_rango_edad AS
SELECT 
  CASE
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) < 20 THEN '-20' 
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 20 AND 29 THEN '20-29'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 30 AND 39 THEN '30-39'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) BETWEEN 40 AND 49 THEN '40-49'
    WHEN TIMESTAMPDIFF(YEAR, c.fecha_nacimiento, CURDATE()) >= 50 THEN '50+'
    ELSE 'Desconocido'
  END AS rango_edad,
  pr.tipo AS tipo_guitarra,
  COUNT(dv.id_detalle) AS cantidad_comprada,
  SUM(dv.subtotal) AS total_gastado
FROM tienda_guitarras.detalle_venta dv
JOIN tienda_guitarras.ventas v ON dv.id_venta = v.id_venta
JOIN tienda_guitarras.clientes c ON v.id_cliente = c.id_cliente
JOIN tienda_guitarras.productos pr ON dv.id_producto = pr.id_producto
WHERE v.estado_venta = 'Pagada'
GROUP BY rango_edad, pr.tipo;