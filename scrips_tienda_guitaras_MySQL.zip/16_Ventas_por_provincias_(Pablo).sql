/*vista_ventas_por_provincia*/
USE tienda_guitarras;

CREATE OR REPLACE VIEW vista_ventas_por_provincia AS
SELECT 
    p.nombre_provincia,
    SUM(v.total) AS total_ventas,
    COUNT(*) AS cantidad_ventas
FROM ventas v
JOIN clientes c ON v.id_cliente = c.id_cliente
JOIN provincias p ON c.id_provincia = p.id_provincia
GROUP BY p.nombre_provincia;