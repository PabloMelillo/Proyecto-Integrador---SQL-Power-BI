-- evolucion de ventas año a año

use tienda_guitarras;

CREATE OR REPLACE VIEW vista_ventas_por_mes_anio AS
SELECT 
  YEAR(v.fecha_venta) AS anio,
  MONTH(v.fecha_venta) AS mes,
  COUNT(*) AS cantidad_ventas,
  SUM(v.total) AS total_facturado
FROM tienda_guitarras.ventas v
WHERE v.estado_venta = 'Pagada'
GROUP BY anio, mes
ORDER BY mes, anio;