-- productos mas vendidos top 10
use tienda_guitarras;
SELECT 
  p.id_producto,
  p.marca,
  p.tipo,
  p.modelo,
  COUNT(d.id_detalle) AS cantidad_ventas_ticket,
  SUM(d.cantidad) AS unidades_vendidas
FROM tienda_guitarras.detalle_venta d
JOIN tienda_guitarras.productos p ON d.id_producto = p.id_producto
GROUP BY p.id_producto, p.marca, p.tipo, p.modelo
ORDER BY unidades_vendidas DESC
LIMIT 10;
-- ------------------------------------------------

-- productos menos vendidos top 10
use tienda_guitarras;
SELECT 
  p.id_producto,
  p.marca,
  p.tipo,
  p.modelo,
  COUNT(d.id_detalle) AS cantidad_ventas_ticket,
  SUM(d.cantidad) AS unidades_vendidas
FROM tienda_guitarras.detalle_venta d
JOIN tienda_guitarras.productos p ON d.id_producto = p.id_producto
GROUP BY p.id_producto, p.marca, p.tipo, p.modelo
ORDER BY unidades_vendidas ASC
LIMIT 10;
