/*
	aca vamos a ver las cantidades de ventas por mes para identificar los meses fuertes y los meses que menos venden. 
	solo vamos a tomar en cuenta los años 2022 al 2024 inclusive para no generar un mal diagnostico dado que el 2025
    siguen en curso

	un analisis rapido demuestra que:
    ventas entre 12156 y 12449 para los meses: 08 (mayor venta),07, 12, 03, 10 y 05
    ventas entre 11065 y 11925 para los meses: 01, 11, 04, 09, 06 y 02(menor venta)
*/    


use tienda_guitarras;

SELECT 
  MONTH(fecha_venta) AS mes,
  COUNT(*) AS cantidad_ventas,
  SUM(total) AS total_recaudado
FROM tienda_guitarras.ventas
WHERE estado_venta = 'Pagada'
	AND YEAR(fecha_venta) IN (2022, 2023, 2024)
GROUP BY mes
ORDER BY cantidad_ventas desc;