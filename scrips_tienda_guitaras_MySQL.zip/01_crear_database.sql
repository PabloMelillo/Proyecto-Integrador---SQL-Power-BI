-- Crear la base de datos
CREATE DATABASE IF NOT EXISTS tienda_guitarras;
USE tienda_guitarras;

-- Tabla de categorías (ej: guitarra acústica, eléctrica, bajo, accesorios)
CREATE TABLE categorias (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    nombre_categoria VARCHAR(50) NOT NULL
);

-- Tabla de productos (las guitarras y otros artículos)
CREATE TABLE productos (
    id_producto INT AUTO_INCREMENT PRIMARY KEY,
    nombre_guitarra VARCHAR(100) NOT NULL,
    marca VARCHAR(50),
    modelo VARCHAR(50),
    tipo VARCHAR(30), -- Ejemplo: acústica, eléctrica, bajo, ukelele
    precio_unitario DECIMAL(10,2),
    stock INT DEFAULT 0,
    id_categoria INT,
    FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria)
);

-- Tabla de clientes
CREATE TABLE clientes (
    id_cliente INT AUTO_INCREMENT PRIMARY KEY,
    nombre_cliente VARCHAR(50),
    apellido_cliente VARCHAR(50),
    email VARCHAR(100),
    telefono VARCHAR(20),
    localidad VARCHAR(50),
    provincia VARCHAR(50), -- esta columna no se usara ya que vamos a crear una tabla donde esten las provincias detalladas con id_provincia para darle mas escabilidad 
    fecha_alta DATE
);

-- Tabla de ventas (cabecera de la operación)
CREATE TABLE ventas (
    id_venta INT AUTO_INCREMENT PRIMARY KEY,
    fecha_venta DATE,
    id_cliente INT,
    total DECIMAL(10,2),
    medio_pago VARCHAR(50), -- Efectivo, tarjeta, transferencia, mercado pago
    estado_venta VARCHAR(20), -- pagada, pendiente, cancelada
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente)
);

-- Tabla detalle de venta (ítems de cada venta)
CREATE TABLE detalle_venta (
    id_detalle INT AUTO_INCREMENT PRIMARY KEY,
    id_venta INT,
    id_producto INT,
    cantidad INT,
    precio_unitario DECIMAL(10,2),
    subtotal DECIMAL(10,2),
    FOREIGN KEY (id_venta) REFERENCES ventas(id_venta),
    FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
);

CREATE TABLE provincias (
    id_provincia INT AUTO_INCREMENT PRIMARY KEY,
    nombre_provincia VARCHAR(50) NOT NULL
);

ALTER TABLE CLIENTES DROP	column PROVINCIA;

ALTER TABLE clientes
ADD COLUMN id_provincia INT,
ADD CONSTRAINT fk_provincia
FOREIGN KEY (id_provincia) REFERENCES provincias(id_provincia);

