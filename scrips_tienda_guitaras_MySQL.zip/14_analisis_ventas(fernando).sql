SELECT * FROM tienda_guitarras.ventas;

SELECT 
YEAR(fecha_venta) AS anio,
       COUNT(*) AS cantidad_ventas,
       SUM(total) AS total_anual
FROM tienda_guitarras.ventas
WHERE estado_venta = 'Pagada'
GROUP BY anio
ORDER BY anio;
/*
	se agrupan las ventas "reales y concretadas" anuales, se contempla la cantidad de ventas y la suma total recibida por año.
    los resultados obtenidos muestran un indice parejo, siendo el año 2022 el que menor cantidad de ventas y total $ recibido posee, estimando
    que la baja de ventas puede darse a la post pandemia covid-19.
    el año 2025 muestra un indice parejo con 2023 y 2024, solo que todavia no termina el año en curso y se puede ver reflejado en los numeros:
		2022, 46578 ventas, 46.678 millones de pesos
        2023, 48624 ventas, 50.327 millones de pesos
        2024, 48397 ventas, 50.503 millones de pesos
        2025, 23957 ventas, 24.941 millones de pesos
*/
SELECT MAX(fecha_venta) AS ultima_venta_2025
FROM tienda_guitarras.ventas
WHERE YEAR(fecha_venta) = 2025; -- aca se puede ver que la ultima fecha de ventas para el 2025 fue en el mes de julio.

-- -------------------------------
SELECT 
YEAR(fecha_venta) AS anio,
       COUNT(*) AS cant_ventas_pendientes,
       SUM(total) AS total_anual
FROM tienda_guitarras.ventas
WHERE estado_venta = 'Pendiente' 
GROUP BY anio
ORDER BY anio;
/*
	analisis de ventas pendientes:
		2022, 8860 ventas, 8.954 millones de pesos
        2023, 9215 ventas, 9.620 millones de pesos
        2024, 9303 ventas, 9.614 millones de pesos
        2025, 4539 ventas, 4.717 millones de pesos
*/

SELECT 
YEAR(fecha_venta) AS anio,
       COUNT(*) AS cant_ventas_canceladas,
       SUM(total) AS total_anual
FROM tienda_guitarras.ventas
WHERE estado_venta = 'Cancelada' 
GROUP BY anio
ORDER BY anio;
/*
	analisis de ventas canceladas:
		2022, 2956 ventas, 2.925 millones de pesos
        2023, 3022 ventas, 3.170 millones de pesos
        2024, 3122 ventas, 3.284 millones de pesos
        2025, 1427 ventas, 1.532 millones de pesos
*/

SELECT YEAR(fecha_venta) AS anio,
       estado_venta,
       COUNT(*) AS cantidad_ventas,
       SUM(total) AS total_facturado
FROM tienda_guitarras.ventas
GROUP BY anio, estado_venta
ORDER BY anio, estado_venta; -- esto seria todo junto


SELECT YEAR(fecha_venta) AS anio,
       ROUND(AVG(total), 2) AS promedio_por_ticket
FROM tienda_guitarras.ventas
WHERE estado_venta = 'Pagada'
GROUP BY anio
ORDER BY anio; -- esto es para ver el promedio de $ por ventas por año.

SELECT YEAR(fecha_venta) AS anio,estado_venta,
       ROUND(AVG(total), 2) AS promedio_por_ticket
FROM tienda_guitarras.ventas
GROUP BY anio, estado_venta
ORDER BY anio, estado_venta; -- aca vemos los promedios $ generales por año y estado de venta. 

/* vamos a crear una CTE para poder visualizar el porcentaje de cada estadao de venta por año*/

WITH ventas_por_anio AS (
  SELECT 
    YEAR(fecha_venta) AS anio,
    estado_venta,
    COUNT(*) AS cantidad
  FROM tienda_guitarras.ventas
  GROUP BY anio, estado_venta
),
total_anual AS (
  SELECT 
    anio,
    SUM(cantidad) AS total_anio
  FROM ventas_por_anio
  GROUP BY anio
)
SELECT 
  v.anio,
  v.estado_venta,
  v.cantidad,
  t.total_anio,
  ROUND((v.cantidad * 100.0 / t.total_anio), 2) AS porcentaje
FROM ventas_por_anio v
JOIN total_anual t ON v.anio = t.anio
ORDER BY v.anio, v.estado_venta;

/*
	ahora haremos una CTE super completa, con 4 mini tablas temporales para luego desglosar en una consulta general, 
    con porcentajes "cantidades" de estado de ventas y de porcentaje de "dinero" de cada estado de ventas
*/
WITH ventas_por_anio AS (
  SELECT 
    YEAR(fecha_venta) AS anio,
    estado_venta,
    COUNT(*) AS cantidad
  FROM tienda_guitarras.ventas
  GROUP BY anio, estado_venta
),
total_anual AS (
  SELECT 
    anio,
    SUM(cantidad) AS total_anio
  FROM ventas_por_anio
  GROUP BY anio
),
monto_por_estado AS (
  SELECT
    YEAR(fecha_venta) AS anio,
    estado_venta,
    SUM(total) AS total_dinero
  FROM tienda_guitarras.ventas
  GROUP BY anio, estado_venta
),
monto_total_anual AS (
  SELECT
    YEAR(fecha_venta) AS anio,
    SUM(total) AS total_dinero_anual
  FROM tienda_guitarras.ventas
  GROUP BY anio
)
SELECT 
  v.anio,
  v.estado_venta,
  v.cantidad,
  t.total_anio,
  ROUND((v.cantidad * 100.0 / t.total_anio), 2) AS porcentaje_ventas,
  m.total_dinero,
  ROUND((m.total_dinero * 100.0 / mt.total_dinero_anual), 2) AS porcentaje_dinero
FROM ventas_por_anio v
JOIN total_anual t ON v.anio = t.anio
LEFT JOIN monto_por_estado m ON v.anio = m.anio AND v.estado_venta = m.estado_venta
LEFT JOIN monto_total_anual mt ON v.anio = mt.anio
ORDER BY v.anio, v.estado_venta;

/* con esta ultima tabla vamos a crear una vista que luego sera aprovechada para usar con Power BI*/