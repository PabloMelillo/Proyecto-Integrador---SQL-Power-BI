-- mejores clientes top 10 ventas realizadas
use tienda_guitarras;
SELECT 
  c.id_cliente,
  c.nombre_cliente,
  c.apellido_cliente,
  p.nombre_provincia,
  COUNT(v.id_venta) AS cantidad_ventas,
  SUM(v.total) AS total_gastado
FROM tienda_guitarras.ventas v
JOIN tienda_guitarras.clientes c ON v.id_cliente = c.id_cliente
JOIN tienda_guitarras.provincias p ON c.id_provincia = p.id_provincia
WHERE v.estado_venta = 'Pagada'
GROUP BY c.id_cliente, c.nombre_cliente, c.apellido_cliente,p.nombre_provincia
ORDER BY total_gastado DESC
LIMIT 10;
