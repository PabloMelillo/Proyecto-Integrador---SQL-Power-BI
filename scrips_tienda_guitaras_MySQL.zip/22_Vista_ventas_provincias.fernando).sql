-- provincias ordenadas por mayores ventas desde el inicio hasta ahora

use tienda_guitarras;
CREATE OR REPLACE VIEW vista_ventas_por_provincia AS
SELECT 
 p.nombre_provincia,
  COUNT(v.id_venta) AS cantidad_ventas,
  SUM(v.total) AS total_facturado
FROM tienda_guitarras.ventas v
JOIN tienda_guitarras.clientes c ON v.id_cliente = c.id_cliente
JOIN tienda_guitarras.provincias p ON c.id_provincia = p.id_provincia
WHERE v.estado_venta = 'Pagada'
GROUP BY p.nombre_provincia
ORDER BY total_facturado DESC;