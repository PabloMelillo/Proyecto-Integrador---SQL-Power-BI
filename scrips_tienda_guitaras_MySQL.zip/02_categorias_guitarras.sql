USE tienda_guitarras;

INSERT INTO categorias (nombre_categoria) VALUES
('Guitarra Acústica'),
('Guitarra Eléctrica'),
('Guitarra Clásica'),
('Guitarra Criolla'),
('Guitarra Electroacústica'),
('Guitarra de 12 Cuerdas'),
('Bajo Eléctrico'),
('Ukelele');