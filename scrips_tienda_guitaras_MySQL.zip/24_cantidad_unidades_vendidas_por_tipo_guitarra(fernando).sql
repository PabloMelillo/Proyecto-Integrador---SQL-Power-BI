-- ventas por tipo de guitarra

use tienda_guitarras;

SELECT 
  p.tipo,
  COUNT(d.id_detalle) AS cantidad_detalles,
  SUM(d.cantidad) AS unidades_vendidas,
  SUM(d.subtotal) AS total_facturado
FROM tienda_guitarras.detalle_venta d
JOIN tienda_guitarras.productos p ON d.id_producto = p.id_producto
JOIN tienda_guitarras.ventas v ON d.id_venta = v.id_venta
WHERE v.estado_venta = 'Pagada'
GROUP BY p.tipo
ORDER BY unidades_vendidas DESC;