CREATE OR REPLACE VIEW vista_medios_pago_top_por_anio AS
SELECT 
    anio,
    medio_pago,
    cantidad_ventas,
    total_facturado
FROM (
    SELECT 
        YEAR(fecha_venta) AS anio,
        medio_pago,
        COUNT(*) AS cantidad_ventas,
        SUM(total) AS total_facturado,
        RANK() OVER (PARTITION BY YEAR(fecha_venta) ORDER BY COUNT(*) DESC) AS ranking
    FROM ventas
    GROUP BY anio, medio_pago
) AS ranked
WHERE ranking = 1
ORDER BY anio;