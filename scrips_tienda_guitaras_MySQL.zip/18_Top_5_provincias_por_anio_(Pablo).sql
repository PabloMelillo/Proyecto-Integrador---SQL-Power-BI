/*Top 5 provincias total facturado por anio*/

CREATE OR REPLACE VIEW vista_top5_provincias_por_anio AS
SELECT 
    anio,
    nombre_provincia,
    total_facturado,
    cantidad_ventas
FROM (
    SELECT 
        YEAR(v.fecha_venta) AS anio,
        p.nombre_provincia,
        SUM(v.total) AS total_facturado,
        COUNT(*) AS cantidad_ventas,
        RANK() OVER (PARTITION BY YEAR(v.fecha_venta) ORDER BY SUM(v.total) DESC) AS ranking
    FROM ventas v
    JOIN clientes c ON v.id_cliente = c.id_cliente
    JOIN provincias p ON c.id_provincia = p.id_provincia
    GROUP BY anio, p.nombre_provincia
) AS ranking_por_anio
WHERE ranking <= 5
ORDER BY anio, ranking;