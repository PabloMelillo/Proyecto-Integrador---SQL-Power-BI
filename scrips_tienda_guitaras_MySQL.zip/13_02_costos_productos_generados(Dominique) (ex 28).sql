
-- Crear tabla de costos vinculada a productos
CREATE TABLE IF NOT EXISTS costos_productos (
  id_producto INT PRIMARY KEY,
  costo_unitario DECIMAL(10,2),
  FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
);

-- Insertar costos estimados con un margen del 60% sobre el precio de venta
INSERT INTO costos_productos (id_producto, costo_unitario)
SELECT
  id_producto,
  ROUND(precio_unitario * 0.60, 2) AS costo_unitario
FROM productos
WHERE precio_unitario IS NOT NULL;
