use tienda_guitarras;

/*
	aca lo que vamos a modificar es la columna "total" de la tabla "ventas". La misma debe devolver la sumatoria de los subtotales
    de la tabla "detalle_venta" para cuando tenga el mismo ID_venta (el cual sera el punto de union del JOIN)
*/    

UPDATE tienda_guitarras.ventas v
JOIN (
  SELECT id_venta, SUM(subtotal) AS nuevo_total
  FROM tienda_guitarras.detalle_venta
  GROUP BY id_venta
) AS subtotales ON v.id_venta = subtotales.id_venta
SET v.total = subtotales.nuevo_total;