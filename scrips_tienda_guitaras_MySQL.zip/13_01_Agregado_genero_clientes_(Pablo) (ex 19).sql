/*Se agregara la columna genero para hacerlo mas escalable*/
ALTER TABLE clientes
DROP COLUMN genero;
SET SQL_SAFE_UPDATES = 0;

alter table clientes add genero enum('Masculino','Femenino','Otro') after apellido_cliente;

-- Asignar femenino
UPDATE clientes
SET genero = 'Femenino'
WHERE nombre_cliente IN ('Abigail', 'Abril', 'Agostina', 'Agustina', 'Alfonsina', 'Alma', 'Alma Jazmin', 'Alma Mia',
 'Alma Valentina', 'Ambar', 'Amparo', 'Ana Paula', 'Angelina', 'Antonella', 'Antonia', 'Bianca', 'Camila', 'Candela',
 'Candelaria', 'Carmela', 'Catalina', 'Charo', 'Clara', 'Constanza', 'Delfina', 'Elena', 'Ema', 'Emilia', 'Felicitas', 
 'Florencia', 'Francesca', 'Francisca', 'Giuliana', 'Guadalupe', 'Guillermina', 'Helena', 'Isabel', 'Isabella', 'Jazmin',
 'Jazmín', 'Joaquina', 'Josefina','Juana', 'Julia', 'Juliana', 'Julieta', 'Justina', 'Kiara', 'Lara','Lola','Lourdes', 'Luana','Lucia', 'Luciana',
'Lucía', 'Ludmila', 'Luisana', 'Luisina', 'Luna', 'Luz Maria', 'Luz Milagros', 'Maia', 'Maite', 'Malena',
'Maria Belen', 'Maria Emilia', 'Maria Guadalupe', 'Maria Luz', 'Maria Paz', 'Maria Victoria', 'Martin', 'Martina',
'Matilda','Mia', 'Mia Jazmin', 'Mia Morena', 'Mia Valentina', 'Micaela','Milagros', 'Milena','Mora', 'Morena', 'Morena Jazmin','Nahiara', 'Nahiara Jazmin','Nina','Olivia', 'Oriana', 'Paloma', 'Paula', 'Paulina','Pilar', 'Priscila','Renata', 'Rosario','Sara','Sofia', 'Sofia Belen', 'Sofía', 'Sol','Tiziana','Uma','Valentina', 'Valentina Jazmin','Victoria', 'Violeta', 'Zoe', 'Zoe Jazmin', 'Zoe Valentina',
'María','Lucía','Sofía','Ana','Carla','Laura','Ana Paula','Angelina','Antonella','Antonia','Bianca','Camila','Candela',
'Candelaria','Carmela','Catalina','Charo','Clara','Constanza','Delfina','Elena','Ema','Emilia','Felicitas','Florencia',
'Francesca','Francisca','Giuliana','Guadalupe','Guillermina','Helena','Isabel','Isabella','Jazmin','Joaquina','Josefina',
'Juana','Julia','Juliana','Julieta','Justina','Kiara','Lara','Lola','Lourdes','Luana','Lucía','Luciana','Ludmila','Luisana','Luisina','Luna','Luz Maria','Luz Milagros','Maia','Maite','Malena','Maria Belen','Maria Emilia','Maria Guadalupe','Maria Luz','Maria Paz','Maria Victoria','Martina','Matilda','Mia','Mia Jazmin','Mia Morena','Mia Valentina','Micaela','Milagros','Milena','Mora','Morena Jazmin','Morena','Morena Jazmin','Nahiara','Nahiara Jazmin','Nina','Olivia','Oriana','Paloma','Paula','Paulina','Pilar','Priscila','Renata','Rosario','Sofia','Sofia Belen','Sol','Tiziana','Uma','Valentina','Valentina Jazmin','Victoria','Violeta','Zoe','Zoe Jazmin','Zoe Valentina','Agustina',
'Ambar','Alma','Valentina','Alma Valentina','Amparo','Abril','Abigail','Alma mia','Lucia','Alma Jazmin','Agostina','Alfonsina'
);

-- Asignar masculino
UPDATE clientes
SET genero = 'Masculino'
WHERE nombre_cliente IN ('Juan', 'Pedro', 'Lucas', 'Carlos', 'Matías', 'Javier','Angel Gabriel','Antonio','Augusto','Bastian','Bautista','Bautista Benjamin','Benicio','Benjamin','Benjamin Alejandro','Benjamin Ezequiel','Bruno','Camilo','Ciro','Ciro Benjamin','Constantino','Dante','Dylan','Dylan Benjamin','Dylan Ezequiel','Emanuel','Emiliano','Emma','Enzo','Ezequiel','Facundo','Facundo','Fausto','Federico','Felipe','Francesco','Francisco','Franco','Gabriel','Gael','Genaro','Geronimo','Gino','Giovanni','Gonzalo','Ian','Ian Benjamin','Ian Ezequiel','Ignacio','Ivan','Jeremias','Jeronimo','Joaquín','Juan','Juan Bautista','Juan Cruz','Juan David','Juan Francisco','Juan Gabriel','Juan Ignacio','Juan Manuel','Juan Martin','Juan Pablo','Juan Sebastian','Julian','Lautaro','Lautaro Benjamin','Lautaro Ezequiel','Lautaro Gabriel','Lautaro Nahuel','Lautaro Nicolas','León','Lisandro','Lorenzo','Luca','Lucas','Lucas Benjamin','Lucas Ezequiel','Luciano','Luciano Benjamin','Lucio','Manuel','Martín','Mateo','Mateo Agustin','Mateo Benjamin','Mateo Ezequiel','Mateo Joaquin','Mateo Valentin','Matias','Maximiliano','Maximo','Miguel Angel','Milo','Nahuel','Nicolas','Octavio','Pedro','Rafael','Ramiro','Renzo','Salvador','Samuel','Santiago','Santiago Benjamin','Santiago Nicolas','Santino','Santino Agustin','Santino Benjamin','Santino Ezequiel','Santino Gabriel','Santino Nicolas','Sara','Sebastian','Simon','Thiago','Thiago Agustin','Thiago Benjamin','Thiago Daniel','Thiago Emanuel','Thiago Ezequiel','Thiago Gabriel','Thiago Joaquin','Thiago Leonel','Thiago Lionel','Thiago Nahuel','Thiago Nicolas','Thiago Valentin','Tiziano','Tiziano Benjamin','Tiziano Valentin','Tobias','Tomàs','Tomas Benjamin','Valentin','Valentino','Vicente','Agustin','Agustín','Faustino','Alexander','Alvaro','Alejo',
'Agustin', 'Agustín', 'Alejo', 'Alexander', 'Alvaro', 'Angel Gabriel', 'Antonio', 'Augusto', 'Bastian', 'Bautista', 'Bautista Benjamin', 'Benicio', 'Benjamin', 'Benjamin Alejandro', 'Benjamin Ezequiel', 'Bruno', 'Camilo', 'Ciro', 'Ciro Benjamin', 'Constantino', 'Dante', 'Dylan', 'Dylan Benjamin', 'Dylan Ezequiel', 'Emanuel', 'Emiliano', 'Emma', 'Enzo', 'Ezequiel', 'Facundo', 'Faustino', 'Fausto', 'Federico', 'Felipe', 'Francesco', 'Francisco', 'Franco', 'Gabriel', 'Gael', 'Genaro', 'Geronimo', 'Gino', 'Giovanni', 'Gonzalo', 'Ian', 'Ian Benjamin', 'Ian Ezequiel', 'Ignacio', 'Ivan', 'Jeremias', 'Jeronimo', 'Joaquin', 'Joaquín', 'Juan', 'Juan Bautista', 'Juan Cruz', 'Juan David', 'Juan Francisco', 'Juan Gabriel', 'Juan Ignacio', 'Juan Manuel', 'Juan Martin', 'Juan Pablo', 'Juan Sebastian', 'Julian',  'Lautaro', 'Lautaro Benjamin', 'Lautaro Ezequiel', 'Lautaro Gabriel', 'Lautaro Nahuel', 'Lautaro Nicolas', 'León', 'Lisandro',  'Lorenzo',  'Luca', 'Lucas', 'Lucas Benjamin', 'Lucas Ezequiel',  'Luciano', 'Luciano Benjamin', 'Lucio',  'Manuel',  'Martín', 'Mateo', 'Mateo Agustin', 'Mateo Benjamin', 'Mateo Ezequiel', 'Mateo Joaquin', 'Mateo Valentin', 'Matias',  'Maximiliano', 'Maximo',  'Miguel Angel',  'Milo',  'Máximo',  'Nahuel', 'Nicolas',  'Octavio',  'Pedro',  'Rafael', 'Ramiro',  'Renzo', 'Salvador', 'Samuel', 'Santiago', 'Santiago Benjamin', 'Santiago Nicolas', 'Santino', 'Santino Agustin', 'Santino Benjamin', 'Santino Ezequiel', 'Santino Gabriel', 'Santino Nicolas',  'Sebastian', 'Simon',  'Thiago', 'Thiago Agustin', 'Thiago Benjamin', 'Thiago Daniel', 'Thiago Emanuel', 'Thiago Ezequiel', 'Thiago Gabriel', 'Thiago Joaquin', 'Thiago Leonel', 'Thiago Lionel', 'Thiago Nahuel', 'Thiago Nicolas', 'Thiago Valentin',  'Tiziano', 'Tiziano Benjamin', 'Tiziano Valentin', 
'Tobias', 'Tomas', 'Tomas Benjamin', 'Tomàs',  'Valentin',  'Valentino', 'Vicente'
);

UPDATE clientes
SET genero = 'Otro'
WHERE genero IS NULL;
