use tienda_guitarras;

/*
	Acá, lo que vamos a hacer es reestablecer en la tabla de "detalle_venta" las columnas 
    de "precio_unitario" (haciendo join con la tabla "productos")
    y calculando el subtotal haciendo "precio_unitario" * "cantidad".
    de esta forma corregimos los datos mal cargados en los tickets de venta.
*/

UPDATE tienda_guitarras.detalle_venta dv
JOIN tienda_guitarras.productos p ON dv.id_producto = p.id_producto
SET
  dv.precio_unitario = p.precio_unitario,
  dv.subtotal = p.precio_unitario * dv.cantidad;