
-- Vista para visualizar costos y márgenes por producto
CREATE OR REPLACE VIEW vista_costos_productos AS
SELECT
  p.id_producto,
  p.nombre_guitarra,
  p.precio_unitario,
  cp.costo_unitario,
  ROUND(p.precio_unitario - cp.costo_unitario, 2) AS margen_unitario,
  ROUND((p.precio_unitario - cp.costo_unitario) / p.precio_unitario * 100, 2) AS margen_porcentual
FROM
  productos p
JOIN
  costos_productos cp ON p.id_producto = cp.id_producto
WHERE
  p.precio_unitario IS NOT NULL AND cp.costo_unitario IS NOT NULL;
